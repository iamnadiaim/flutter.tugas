package com.example.assesmentmobile1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
