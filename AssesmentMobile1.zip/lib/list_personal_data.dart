import 'package:flutter/material.dart';

class Second extends StatelessWidget {
  final String fullName;
  final String email;
  final String phoneNumber;
  final String personalID;
  final String address;

  Second({
    required this.fullName,
    required this.email,
    required this.phoneNumber,
    required this.personalID,
    required this.address,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'List Personal Data',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: [
          _buildPersonalDataCard(),
        ],
      ),
    );
  }

  Widget _buildPersonalDataCard() {
    return Container(
      padding: EdgeInsets.all(12.0),
      margin: EdgeInsets.only(bottom: 12.0),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 1),
        borderRadius: BorderRadius.circular(5.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildPersonalDataItem('Full Name:', fullName),
          _buildPersonalDataItem('Email:', email),
          _buildPersonalDataItem('Phone Number:', phoneNumber),
          _buildPersonalDataItem('Personal ID:', personalID),
          _buildPersonalDataItem('Address:', address),
        ],
      ),
    );
  }

  Widget _buildPersonalDataItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(value),
      ],
    );
  }
}
